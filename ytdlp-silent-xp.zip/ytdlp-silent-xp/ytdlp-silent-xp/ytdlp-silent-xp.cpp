// ytdlp-silent-xp.cpp : Defines the entry point for the application.
//
#include "stdafx.h"
#include <windows.h>
#include <shellapi.h>
#include <string>
#include <fstream>

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    int argc = 0;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    
    std::wstring command;
    
    // Parse command line for -s parameter
    for (int i = 1; i < argc; ++i) {
        if (std::wstring(argv[i]) == L"-s" && i + 1 < argc) {
            command = argv[i + 1];
            break;
        }
    }
    
    if (command.empty()) {
        if (argv) LocalFree(argv);
        return 1;
    }
    
    // Create pipe for output
    SECURITY_ATTRIBUTES saAttr;
    saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
    saAttr.bInheritHandle = TRUE;
    saAttr.lpSecurityDescriptor = NULL;
    
    HANDLE hReadPipe = NULL, hWritePipe = NULL;
    if (!CreatePipe(&hReadPipe, &hWritePipe, &saAttr, 0)) {
        if (argv) LocalFree(argv);
        return 1;
    }
    
    STARTUPINFOW si;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.hStdOutput = hWritePipe;
    si.hStdError = hWritePipe;
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    
    PROCESS_INFORMATION pi;
    ZeroMemory(&pi, sizeof(pi));
    
    wchar_t* cmdLine = _wcsdup(command.c_str());
    
    // CREATE_NO_WINDOW prevents console window from appearing
    if (CreateProcessW(NULL, cmdLine, NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        CloseHandle(hWritePipe); // Close write end in parent
        
        // Read output from pipe
        DWORD dwRead;
        char buffer[4096];
        std::string output;
        
        while (ReadFile(hReadPipe, buffer, sizeof(buffer) - 1, &dwRead, NULL) && dwRead > 0) {
            buffer[dwRead] = '\0';
            output.append(buffer, dwRead);
        }
        
        // Wait for process to finish
        WaitForSingleObject(pi.hProcess, INFINITE);
        
        // ALWAYS write output to file so Lua script can read it
        std::ofstream outFile("yt-dlp-output.txt", std::ios::out | std::ios::trunc);
        if (outFile.is_open()) {
            outFile << output;
            outFile.close();
        }
        
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        CloseHandle(hReadPipe);
    } else {
        CloseHandle(hWritePipe);
        CloseHandle(hReadPipe);
    }
    
    free(cmdLine);
    if (argv) LocalFree(argv);
    
    return 0;
}